for D in *; do
	echo -ne "${D} \t" 
	echo -ne "$(sed '2!d' ${D})" 
	echo -ne "${D} \t" 
	echo -ne "$(sed '8!d' ${D})" 
	echo -ne "${D} \t" 
	echo -ne "$(sed '14!d' ${D})" 
	echo -e "@@@"
done

package highlights;

public class PrjSummary {
	static String SEPARATOR = "\t";
	
	String projectName = "";
	String fileName = "";
	int numMonthsPostV0 = -1;
	
	//Schema
	int monthOfSchemaBirth = -1;
	double pctOfSchemaEvoAtSchemaBirth = -1.0;	
	double timeProgressAtSchemaBirth = -1.0;
	
	int monthOfReachingTopBandCumSchemaActivity = -1;
	double timeProgressAtSchemaTopBand = -1.0;
	double pctOfSchemaEvoAtTopBand = -1.0;
	boolean hasSingleVault = false;

	//growth period from birth to top band
	double schemaBirthToTopBandPctInterval = -1.0;
	int schemaBirthToTopBandMonths = -1;
//new stuff
	int schemaBirthToTopMonthsWithoutChange = 0;
	int schemaBirthToTopMonthsWithChange = 0;
	double pctActiveMonthsInBirthToTop = 0.0;
	double pctActiveBirthToTopOverDuration = 0.0;

	//tail
	double schemaTopBandToEndPctInterval = -1.0;
	int schemaTopBandToEndMonths = -1;
	
	//PRJ
	double pctPrjActivityAtV0 = -1.0;
	String labelPrjActivityAtV0 = "";
	int monthOfReachingTopBandCumPrjActivity = -1;
	double timeProgressAtPrjTopBand = -1.0;
	boolean hasTailAtPrjTopBand = false;

	
	
	public String toString() {
		return projectName + SEPARATOR + numMonthsPostV0 + SEPARATOR + timeProgressAtSchemaBirth + SEPARATOR + monthOfSchemaBirth + SEPARATOR + pctOfSchemaEvoAtSchemaBirth 
				+ SEPARATOR + monthOfReachingTopBandCumSchemaActivity + SEPARATOR + timeProgressAtSchemaTopBand + SEPARATOR + hasSingleVault
				+ SEPARATOR + schemaBirthToTopBandPctInterval + SEPARATOR + schemaBirthToTopBandMonths 
				+ SEPARATOR + schemaTopBandToEndPctInterval + SEPARATOR + schemaTopBandToEndMonths 
				+ SEPARATOR + pctPrjActivityAtV0 + SEPARATOR + labelPrjActivityAtV0
				+ SEPARATOR + monthOfReachingTopBandCumPrjActivity + SEPARATOR + timeProgressAtPrjTopBand + SEPARATOR + hasTailAtPrjTopBand
				+ SEPARATOR + schemaBirthToTopMonthsWithChange + SEPARATOR  + schemaBirthToTopMonthsWithoutChange 
				+ SEPARATOR + pctActiveMonthsInBirthToTop + SEPARATOR  + pctActiveBirthToTopOverDuration
				;

	}//end toString()
	
}//end class

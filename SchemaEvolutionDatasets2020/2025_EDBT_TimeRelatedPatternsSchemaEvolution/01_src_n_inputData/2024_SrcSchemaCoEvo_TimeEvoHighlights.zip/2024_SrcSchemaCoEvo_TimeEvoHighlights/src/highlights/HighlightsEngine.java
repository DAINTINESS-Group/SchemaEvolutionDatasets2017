package highlights;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;



public class HighlightsEngine {

	private class LagMeasurement{
		int month;
		int schActivity;
		int prjActivity;
		int totalActivity;
		double cumulPtime ;
		double cumulSchActivity ;
		double cumulPrjActivity ;
		double timeLagOverSchema ; 
		double srcLagOverSchema;

		public String toString(){
			return month + SEPARATOR + totalActivity + SEPARATOR + schActivity + SEPARATOR + prjActivity + SEPARATOR 
					+ String.valueOf(cumulPtime) + SEPARATOR 
					+ String.valueOf(cumulSchActivity) + SEPARATOR 
					+ String.valueOf(cumulPrjActivity) + SEPARATOR
					+ String.valueOf(timeLagOverSchema) + SEPARATOR
					+ String.valueOf(srcLagOverSchema) + SEPARATOR
					;
		}
	}//end LagMeasurement


	

	public final String SEPARATOR = "\t";
	public String HEADER = "fileName" + SEPARATOR + "numMonthsPostV0" + SEPARATOR + "timePctAtSchemaBirth" 
	+ SEPARATOR + "monthOfSchemaBirth" + SEPARATOR + "pctOfSchemaEvoAtSchemaBirth" 
	+ SEPARATOR + "monthOfTopBand" + SEPARATOR + "timeProgressAtSchemaTopBand" + SEPARATOR + "hasSingleVault"
	+ SEPARATOR + "schemaBirthToTopBandPctInterval" + SEPARATOR + "schemaBirthToTopBandMonths" 
	+ SEPARATOR + "schemaTopBandToEndPctInterval" + SEPARATOR + "schemaTopBandToEndMonths" 
	+ SEPARATOR + "pctPrjActivityAtV0" + SEPARATOR + "labelPrjActivityAtV0"
	+ SEPARATOR + "monthOfReachingTopBandCumPrjActivity" + SEPARATOR + "timeProgressAtPrjTopBand" + SEPARATOR + "hasTailAtPrjTopBand"
	+ SEPARATOR + "schemaBirthToTopMonthsWithChange" +  SEPARATOR  + "schemaBirthToTopMonthsWithoutChange"
	+ SEPARATOR + "pctActiveMonthsInBirthToTop" + SEPARATOR + "pctActiveBirthToTopOverDuration"
	;
	
	List<PrjSummary> prjInfo;
	String INPUT_FOLDER = "";

	
	public HighlightsEngine(String inputFolder) {
		this.prjInfo = new ArrayList<PrjSummary>();
		this.INPUT_FOLDER = inputFolder;
	}

	
	/**
	 * Does all the job of producing highlights
	 * 
	 * @return the number of months + 1 (for the V0)
	 */
	public int performLagComputation() {	
		String[] inputFileArray;
		PrjSummary.SEPARATOR = this.SEPARATOR;
		
		File inputFolderFile = new File(INPUT_FOLDER);
		inputFileArray = inputFolderFile.list();
		Arrays.sort(inputFileArray);

		if(inputFileArray != null) {
			System.out.println(HEADER);

			for (String fileName : inputFileArray) {
				PrjSummary prjSum = processSingleFile(fileName);
				prjInfo.add(prjSum);
			}

		}


		return prjInfo.size();
	}//end performLagComputation()

	/**
	 * Given a file in the input folder, it processes it
	 * 
	 * @param pFileName the name of the file with the cumulative stats.
	 */
	private PrjSummary processSingleFile(String pFileName) {
		String inputFileName = INPUT_FOLDER + "/" + pFileName; //+ File.separator
//		String outputFileName = OUTPUT_FOLDER + "/" + pFileName; //+ File.separator
		//System.out.println(inputFileName);
		//System.out.println(outputFileName);

		Scanner inputStream = null;
		try {
			inputStream = new Scanner(new FileInputStream(inputFileName));
		} catch (FileNotFoundException e) {
			System.err.println("Problem opening file: " + inputFileName);
			System.exit(0);
		}

		// Read the first line - header
		inputStream.nextLine();

		List<LagMeasurement> measurementsList = new ArrayList<LagMeasurement>();

		processNextInputLine(inputFileName, inputStream, measurementsList);
		inputStream.close();
		
		//produce Highlights
		PrjSummary prjSummary = reportHighlights(measurementsList, pFileName);
		System.out.println(prjSummary.toString());
		return prjSummary;
	}//end ProcessSingleFile

	
	/**
	 * @param measurementsList
	 */
	private PrjSummary reportHighlights(List<LagMeasurement> measurementsList, String fileName) {
		String projectName = fileName.replaceFirst("cumulative_","").replaceFirst(".tsv", "");
		
		PrjSummary prjSummary = new PrjSummary();
		prjSummary.projectName = projectName;
		prjSummary.fileName = fileName;
		prjSummary.numMonthsPostV0 = measurementsList.size()-1;
		
		int currentMonth = 0;
		
		boolean foundSchemaBirth = false;
		boolean foundTopBandCumSchemaActivity = false;
		double TOP_BAND_CUM_SCH_ACTIVITY_THRESHOLD = 0.9;
		double SINGLE_VAULT_TIME_THRESHOLD = 0.1;

		double TOP_BAND_CUM_PRJ_ACTIVITY_THRESHOLD = 0.9;
		double PRJ_TAIL_TIME_THRESHOLD = 0.8;
		boolean foundTopBandCumPrjActivity = false; 
		
		double previousSchemaActivity = 0.0;
		//iterate over all months, except the last where all is 100%; the second index of sublist() is __excluded__
		for(LagMeasurement lagM : measurementsList) {

			//SCHEMA STATS			
			//find the highlights of schema birth
			foundSchemaBirth = studySchemaBirth(prjSummary, currentMonth, foundSchemaBirth, lagM);
			//find the highlights of schema top-band
			foundTopBandCumSchemaActivity = studyPointOfReachingSchemaTopBand(prjSummary, currentMonth, foundTopBandCumSchemaActivity,
					TOP_BAND_CUM_SCH_ACTIVITY_THRESHOLD, SINGLE_VAULT_TIME_THRESHOLD, lagM);
			//process the growth period between birth and topBand
			if ((foundSchemaBirth==true)&&(foundTopBandCumSchemaActivity==false)) {
				previousSchemaActivity = processGrowthPeriod(prjSummary, previousSchemaActivity, lagM);
			}
			// /////////////////////////////////////
			
			//PRJ STATS
			//let's find out about the prj activity at V0
			studyPrjAtV0(prjSummary, currentMonth, lagM);
			
			//WHAT PATTERNS CAN WE EXTRACT FOR PRJ LIFE?
			//is it possible that it is a low-starter (the "mirror" of a tail)
			//what happens for the 20% of time - 50% of time - 80% of time
			//what happens for the 20% of activity - 50% of activity - 80% of activity
			
			//when does it get into prj top-band? Does it have a tail?
			foundTopBandCumPrjActivity = studyPrjTopBand(prjSummary, currentMonth, TOP_BAND_CUM_PRJ_ACTIVITY_THRESHOLD,
					PRJ_TAIL_TIME_THRESHOLD, foundTopBandCumPrjActivity, lagM);
			
			
			//Don't forget to increment the month
			currentMonth++;
		}//end for
		

		performFinalComputations(prjSummary);
		
//		System.err.println(prjSummary.fileName + "\t" + prjSummary.numMonthsPostV0 + "\t" + prjSummary.schemaBirthToTopBandMonths + "\t" 
//				+ prjSummary.monthOfSchemaBirth + "\t" + prjSummary.monthOfReachingTopBandCumSchemaActivity + "\t"
//				+ prjSummary.schemaBirthToTopMonthsWithChange + "\t" + prjSummary.schemaBirthToTopMonthsWithoutChange + "\t"
//				+ "\t" + prjSummary.pctActiveMonthsInBirthToTop + "\t" + prjSummary.pctActiveBirthToTopOverDuration
//				);
		return prjSummary;
	}


	/**
	 * Updates the project Summary with the final stats
	 * 
	 * For the growth period: we need more than one month within the clean interval (birth...topBand)
	 * The prjSummary.schemaBirthToTopBandMonths already includes birth, so we need it to be strictly more than 1.
	 * 
	 * @param prjSummary  the ProjectSummary that is updated with change counters
	 */
	private void performFinalComputations(PrjSummary prjSummary) {
		if (prjSummary.schemaBirthToTopBandMonths > 1) {
			prjSummary.pctActiveMonthsInBirthToTop = (double)prjSummary.schemaBirthToTopMonthsWithChange /(double)(prjSummary.schemaBirthToTopBandMonths - 1);
			prjSummary.pctActiveBirthToTopOverDuration = (double)prjSummary.schemaBirthToTopMonthsWithChange /(double)(prjSummary.numMonthsPostV0);
		}
	}


	/**
	 * Counts how often there is a change in the {growth period} between birth and attainment of TopBand.
	 * 
	 * The counting counts the interval (MonthOfBirth ... MonthOfTopBand), i.e., the 2 extremes are not included.
	 * This means that when MonthOfBirth == MonthOfTopBand, or MonthOfBirth == MonthOfTopBand-1,
	 * there is no growth period between them.
	 * 
	 * Basically, we count how many months in the growth period have schema change, and how many do not
	 * 
	 * @param prjSummary  the ProjectSummary that is updated with change counters
	 * @param previousSchemaActivity A double with the cumul. activity of the schema for the previous month (facilitating the detection of change)
	 * @param lagM the LagMeasurement for the month being processed
	 * @return the value of the cumulative schema activity of the current month (to populate the previous schema activity in the client)
	 */
	private double processGrowthPeriod(PrjSummary prjSummary, double previousSchemaActivity, LagMeasurement lagM) {
		if (previousSchemaActivity == 0.0)
			;
		else if (lagM.cumulSchActivity == previousSchemaActivity)
			prjSummary.schemaBirthToTopMonthsWithoutChange++;
		else
			prjSummary.schemaBirthToTopMonthsWithChange++;
		
		previousSchemaActivity = lagM.cumulSchActivity;
		return previousSchemaActivity;
	}


	/**
	 * Assesses how much of prj.activity V0 holds
	 * 
	 * @param prjSummary
	 * @param currentMonth
	 * @param lagM
	 */
	private void studyPrjAtV0(PrjSummary prjSummary, int currentMonth, LagMeasurement lagM) {
		if(currentMonth == 0) {
			prjSummary.pctPrjActivityAtV0 = lagM.cumulPrjActivity;
			if(prjSummary.pctPrjActivityAtV0 < 0.2)
				prjSummary.labelPrjActivityAtV0 = "1_REASONABLE";
			else if(prjSummary.pctPrjActivityAtV0 < 0.4)
				prjSummary.labelPrjActivityAtV0 = "2_MILD";
			else if(prjSummary.pctPrjActivityAtV0 < 0.8)
				prjSummary.labelPrjActivityAtV0 = "3_SIGNIFICANT";
			else prjSummary.labelPrjActivityAtV0 = "4_EXTREME";
		}
	}


	/**
	 * @param prjSummary
	 * @param currentMonth
	 * @param TOP_BAND_CUM_PRJ_ACTIVITY_THRESHOLD
	 * @param foundTopBandCumPrjActivity
	 * @param lagM
	 * @return
	 */
	private boolean studyPrjTopBand(PrjSummary prjSummary, int currentMonth, double TOP_BAND_CUM_PRJ_ACTIVITY_THRESHOLD,
			double PRJ_TAIL_TIME_THRESHOLD,	boolean foundTopBandCumPrjActivity, LagMeasurement lagM) {
		if((lagM.cumulPrjActivity >= TOP_BAND_CUM_PRJ_ACTIVITY_THRESHOLD)&&(foundTopBandCumPrjActivity == false)) {
			foundTopBandCumPrjActivity = true;
			prjSummary.monthOfReachingTopBandCumPrjActivity = currentMonth;
			prjSummary.timeProgressAtPrjTopBand = lagM.cumulPtime;	
			
			if(prjSummary.timeProgressAtPrjTopBand < PRJ_TAIL_TIME_THRESHOLD) {
				prjSummary.hasTailAtPrjTopBand = true;
			}
		}
		return foundTopBandCumPrjActivity;
	}


	/**
	 * Studies when the schema enters it's top band and whether this is actually soon after schema birth (single vault)
	 * 
	 * THe interval between birth and topBand includes birth. E.g., if born at m1 and topBand at m5, 
	 * we count months {1,2,3,4} i.e., the interval == 4 months. Equiv., m5-m1 = 4 months.
	 * 
	 * MUST run AFTER birth detection
	 * 
	 * @param prjSummary
	 * @param currentMonth
	 * @param foundTopBandCumSchemaActivity
	 * @param TOP_BAND_CUM_SCH_ACTIVITY_THRESHOLD
	 * @param SINGLE_SPIKE_TIME_THRESHOLD
	 * @param lagM
	 * @return
	 */
	private boolean studyPointOfReachingSchemaTopBand(PrjSummary prjSummary, int currentMonth, boolean foundTopBandCumSchemaActivity,
			double TOP_BAND_CUM_SCH_ACTIVITY_THRESHOLD, double SINGLE_SPIKE_TIME_THRESHOLD, LagMeasurement lagM) {
		if((lagM.cumulSchActivity >= TOP_BAND_CUM_SCH_ACTIVITY_THRESHOLD) 
				&& (foundTopBandCumSchemaActivity == false)) {
			foundTopBandCumSchemaActivity = true;
			prjSummary.monthOfReachingTopBandCumSchemaActivity = currentMonth;
			prjSummary.timeProgressAtSchemaTopBand = lagM.cumulPtime;
			
			prjSummary.schemaBirthToTopBandPctInterval = prjSummary.timeProgressAtSchemaTopBand - prjSummary.timeProgressAtSchemaBirth;
			prjSummary.schemaBirthToTopBandMonths = prjSummary.monthOfReachingTopBandCumSchemaActivity - prjSummary.monthOfSchemaBirth;
			//if there is less than SINGLE_SPIKE_TIME_THRESHOLD of time
			//between birth and top band, then we have a single spike
			if(prjSummary.timeProgressAtSchemaTopBand - prjSummary.timeProgressAtSchemaBirth <= SINGLE_SPIKE_TIME_THRESHOLD)
				prjSummary.hasSingleVault = true;
			
			prjSummary.schemaTopBandToEndPctInterval = 1.0 - prjSummary.timeProgressAtSchemaTopBand;
			prjSummary.schemaTopBandToEndMonths = prjSummary.numMonthsPostV0  - prjSummary.monthOfReachingTopBandCumSchemaActivity;
		}//end @entering topBand
		return foundTopBandCumSchemaActivity;
	}


	/**
	 * Studies the schema birth (when, which pct of PUP, how much % of total schema evo did it have, ...)
	 * 
	 * @param prjSummary
	 * @param currentMonth
	 * @param foundSchemaBirth
	 * @param lagM
	 * @return
	 */
	private boolean studySchemaBirth(PrjSummary prjSummary, int currentMonth, boolean foundSchemaBirth,
			LagMeasurement lagM) {
		if((lagM.cumulSchActivity > 0.0) && (foundSchemaBirth == false)) {
			foundSchemaBirth = true;
			prjSummary.monthOfSchemaBirth = currentMonth;
			prjSummary.pctOfSchemaEvoAtSchemaBirth = lagM.cumulSchActivity;
			prjSummary.timeProgressAtSchemaBirth = lagM.cumulPtime;
			//System.out.println("BIRTH: " + currentMonth);
		}//end @birth
		return foundSchemaBirth;
	}


	/**
	 * Processes every next line from the input file, makes an object and adds it to the collection
	 * 
	 * @param inputFileName
	 * @param inputStream
	 * @param measurementsList
	 * @throws NumberFormatException
	 */
	private void processNextInputLine(String inputFileName, Scanner inputStream, List<LagMeasurement> measurementsList)
			throws NumberFormatException {
		String line;
		String[] tokens;
		while (inputStream.hasNextLine()) {
			line = inputStream.nextLine();
			tokens = line.split(SEPARATOR);			
			if (tokens.length != 6) {
				System.err.println("Not proper structure of 6 tokens in input file: " + inputFileName);
				System.exit(0);
			}

			LagMeasurement lagMeasurement = new LagMeasurement();

			//process the input line
			//Month	SchActivity	PrjActivity	cumulPtime	cumulSchActivity	cumulPrjActivity
			lagMeasurement.month = Integer.parseInt(tokens[0]);
			lagMeasurement.schActivity	= Integer.parseInt(tokens[1]);
			lagMeasurement.prjActivity = Integer.parseInt(tokens[2]);
			lagMeasurement.cumulPtime = Double.parseDouble(tokens[3]);
			lagMeasurement.cumulSchActivity = Double.parseDouble(tokens[4]);
			lagMeasurement.cumulPrjActivity = Double.parseDouble(tokens[5]);
			lagMeasurement.timeLagOverSchema = lagMeasurement.cumulSchActivity - lagMeasurement.cumulPtime; 
			lagMeasurement.srcLagOverSchema = lagMeasurement.cumulSchActivity - lagMeasurement.cumulPrjActivity;
			lagMeasurement.totalActivity = lagMeasurement.schActivity + lagMeasurement.prjActivity;
			measurementsList.add(lagMeasurement);
			//System.out.println(lagMeasurement.toString());			
		}
	}//end processNextInputLine

}//end class

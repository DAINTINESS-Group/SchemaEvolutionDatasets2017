package highlights;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

public class HighlightsEngineTest {
	private static HighlightsEngine engine;
	private static final String INPUT_FOLDER = "./resources/incoming/TestInputFolder";
	private static Map<String,PrjSummary> map;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		engine = new HighlightsEngine(INPUT_FOLDER);
		map = new HashMap<String,PrjSummary>();
	}

	@Test
	public void testPerformLagComputation() {
		int numPrjProcessed = engine.performLagComputation();
		assertEquals(7,numPrjProcessed);
		for (PrjSummary i : engine.prjInfo) map.put(i.projectName,i);

		//Frozen
		PrjSummary shopware__shopware = map.get("shopware__shopware");
		assertEquals(81,shopware__shopware.numMonthsPostV0);
		assertEquals(12,shopware__shopware.monthOfSchemaBirth);
		assertEquals(1.0,shopware__shopware.pctOfSchemaEvoAtSchemaBirth, 2);
		assertEquals(0.15,shopware__shopware.timeProgressAtSchemaBirth, 2);
		assertEquals(12,shopware__shopware.monthOfReachingTopBandCumSchemaActivity);
		assertEquals(0.15,shopware__shopware.timeProgressAtSchemaTopBand, 2);
		assertTrue(shopware__shopware.hasSingleVault);
		assertEquals(0.0, shopware__shopware.schemaBirthToTopBandPctInterval, 2);
		assertEquals(0, shopware__shopware.schemaBirthToTopBandMonths);
		assertEquals(1 - 0.1481, shopware__shopware.schemaTopBandToEndPctInterval, 2);
		assertEquals(69, shopware__shopware.schemaTopBandToEndMonths);
		assertEquals("1_REASONABLE", shopware__shopware.labelPrjActivityAtV0);
		assertEquals(69, shopware__shopware.monthOfReachingTopBandCumPrjActivity);
		assertEquals(0.85, shopware__shopware.timeProgressAtPrjTopBand, 2);
		assertEquals(false, shopware__shopware.hasTailAtPrjTopBand);		
		assertEquals(0, shopware__shopware.schemaBirthToTopMonthsWithoutChange);
		assertEquals(0, shopware__shopware.schemaBirthToTopMonthsWithChange);
		assertEquals(0.0, shopware__shopware.pctActiveMonthsInBirthToTop, 2);
		assertEquals(0.0, shopware__shopware.pctActiveBirthToTopOverDuration, 2);

		
		//AF
		PrjSummary mozillaServices__autograph = map.get("mozilla-services__autograph");
		assertEquals(40,mozillaServices__autograph.numMonthsPostV0);
		assertEquals(37,mozillaServices__autograph.monthOfSchemaBirth);
		assertEquals(1.0,mozillaServices__autograph.pctOfSchemaEvoAtSchemaBirth, 2);
		assertEquals(0.93,mozillaServices__autograph.timeProgressAtSchemaBirth, 2);
		assertEquals(37,mozillaServices__autograph.monthOfReachingTopBandCumSchemaActivity);
		assertEquals(0.93,mozillaServices__autograph.timeProgressAtSchemaTopBand, 2);
		assertTrue(mozillaServices__autograph.hasSingleVault);
		assertEquals(0.0, mozillaServices__autograph.schemaBirthToTopBandPctInterval, 2);
		assertEquals(0, mozillaServices__autograph.schemaBirthToTopBandMonths);
		assertEquals(0.075, mozillaServices__autograph.schemaTopBandToEndPctInterval, 2);
		assertEquals(3, mozillaServices__autograph.schemaTopBandToEndMonths);		
		assertEquals("1_REASONABLE", mozillaServices__autograph.labelPrjActivityAtV0);
		assertEquals(36, mozillaServices__autograph.monthOfReachingTopBandCumPrjActivity);
		assertEquals(0.9, mozillaServices__autograph.timeProgressAtPrjTopBand, 2);
		assertEquals(false, mozillaServices__autograph.hasTailAtPrjTopBand);
		assertEquals(0, mozillaServices__autograph.schemaBirthToTopMonthsWithoutChange);
		assertEquals(0, mozillaServices__autograph.schemaBirthToTopMonthsWithChange);
		assertEquals(0.0, mozillaServices__autograph.pctActiveMonthsInBirthToTop, 2);
		assertEquals(0.0, mozillaServices__autograph.pctActiveBirthToTopOverDuration, 2);

		
		//FS-FR
		PrjSummary accgit__acl = map.get("accgit__acl");
		assertEquals(21,accgit__acl.numMonthsPostV0);
		assertEquals(0,accgit__acl.monthOfSchemaBirth);
		assertEquals(0.38,accgit__acl.pctOfSchemaEvoAtSchemaBirth, 2);
		assertEquals(0.0,accgit__acl.timeProgressAtSchemaBirth, 2);
		assertEquals(4,accgit__acl.monthOfReachingTopBandCumSchemaActivity);
		assertEquals(0.66,accgit__acl.timeProgressAtSchemaTopBand, 2);
		assertFalse(accgit__acl.hasSingleVault);
		assertEquals(0.97, accgit__acl.schemaBirthToTopBandPctInterval, 2);
		assertEquals(4, accgit__acl.schemaBirthToTopBandMonths);
		assertEquals(0.029, accgit__acl.schemaTopBandToEndPctInterval, 2);
		assertEquals(17, accgit__acl.schemaTopBandToEndMonths);	
		assertEquals("1_REASONABLE", accgit__acl.labelPrjActivityAtV0);
		assertEquals(14, accgit__acl.monthOfReachingTopBandCumPrjActivity);
		assertEquals(0.67, accgit__acl.timeProgressAtPrjTopBand, 2);
		assertEquals(true, accgit__acl.hasTailAtPrjTopBand);
		assertEquals(2, accgit__acl.schemaBirthToTopMonthsWithoutChange);
		assertEquals(1, accgit__acl.schemaBirthToTopMonthsWithChange);
		assertEquals(1/3, accgit__acl.pctActiveMonthsInBirthToTop, 2);
		assertEquals(1/21, accgit__acl.pctActiveBirthToTopOverDuration, 2);
		
		
		//MODERATE
		PrjSummary aiyi__goUser = map.get("aiyi__go-user");
		assertEquals(1,aiyi__goUser.numMonthsPostV0);
		assertEquals(0,aiyi__goUser.monthOfSchemaBirth);
		assertEquals(1.0,aiyi__goUser.pctOfSchemaEvoAtSchemaBirth, 2);
		assertEquals(0.0,aiyi__goUser.timeProgressAtSchemaBirth, 2);
		assertEquals(0,aiyi__goUser.monthOfReachingTopBandCumSchemaActivity);
		assertEquals(0.0,aiyi__goUser.timeProgressAtSchemaTopBand, 2);
		assertEquals(0.0,aiyi__goUser.schemaBirthToTopBandPctInterval, 2);
		assertEquals(0, aiyi__goUser.schemaBirthToTopBandMonths);
		assertEquals(1.0, aiyi__goUser.schemaTopBandToEndPctInterval, 2);
		assertEquals(1, aiyi__goUser.schemaTopBandToEndMonths);
		assertTrue(aiyi__goUser.hasSingleVault);		
		assertEquals("3_SIGNIFICANT", aiyi__goUser.labelPrjActivityAtV0);
		assertEquals(1, aiyi__goUser.monthOfReachingTopBandCumPrjActivity);
		assertEquals(1.0, aiyi__goUser.timeProgressAtPrjTopBand, 2);
		assertEquals(false, aiyi__goUser.hasTailAtPrjTopBand);
		assertEquals(0, aiyi__goUser.schemaBirthToTopMonthsWithoutChange);
		assertEquals(0, aiyi__goUser.schemaBirthToTopMonthsWithChange);
		assertEquals(0.0, aiyi__goUser.pctActiveMonthsInBirthToTop, 2);
		assertEquals(0.0, aiyi__goUser.pctActiveBirthToTopOverDuration, 2);

		
		//AF LOW
		PrjSummary h2oai__steam = map.get("h2oai__steam");
		assertEquals(36,h2oai__steam.numMonthsPostV0);
		assertEquals(4,h2oai__steam.monthOfSchemaBirth);
		assertEquals(0.65,h2oai__steam.pctOfSchemaEvoAtSchemaBirth, 2);
		assertEquals(0.11,h2oai__steam.timeProgressAtSchemaBirth, 2);
		assertEquals(5,h2oai__steam.monthOfReachingTopBandCumSchemaActivity);
		assertEquals(0.14,h2oai__steam.timeProgressAtSchemaTopBand, 2);
		assertTrue(h2oai__steam.hasSingleVault);	
		assertEquals(0.03,h2oai__steam.schemaBirthToTopBandPctInterval, 2);
		assertEquals(1, h2oai__steam.schemaBirthToTopBandMonths);
		assertEquals(0.861, h2oai__steam.schemaTopBandToEndPctInterval, 2);
		assertEquals(31, h2oai__steam.schemaTopBandToEndMonths);
		assertEquals("1_REASONABLE", h2oai__steam.labelPrjActivityAtV0);
		assertEquals(6, h2oai__steam.monthOfReachingTopBandCumPrjActivity);
		assertEquals(0.17, h2oai__steam.timeProgressAtPrjTopBand, 2);
		assertEquals(true, h2oai__steam.hasTailAtPrjTopBand);
		assertEquals(0, h2oai__steam.schemaBirthToTopMonthsWithoutChange);
		assertEquals(0, h2oai__steam.schemaBirthToTopMonthsWithChange);
		assertEquals(0.0, h2oai__steam.pctActiveMonthsInBirthToTop, 2);
		assertEquals(0.0, h2oai__steam.pctActiveBirthToTopOverDuration, 2);
		
		
		//ACTIVE
		PrjSummary quickapps__cms = map.get("quickapps__cms");
		assertEquals(49,quickapps__cms.numMonthsPostV0);
		assertEquals(11,quickapps__cms.monthOfSchemaBirth);
		assertEquals(0.56,quickapps__cms.pctOfSchemaEvoAtSchemaBirth, 2);
		assertEquals(0.22,quickapps__cms.timeProgressAtSchemaBirth, 2);
		assertEquals(13,quickapps__cms.monthOfReachingTopBandCumSchemaActivity);
		assertEquals(0.27,quickapps__cms.timeProgressAtSchemaTopBand, 2);
		assertTrue(quickapps__cms.hasSingleVault);
		assertEquals(0.042,quickapps__cms.schemaBirthToTopBandPctInterval, 2);
		assertEquals(2, quickapps__cms.schemaBirthToTopBandMonths);
		assertEquals(0.736, quickapps__cms.schemaTopBandToEndPctInterval, 2);
		assertEquals(36, quickapps__cms.schemaTopBandToEndMonths);	
		assertEquals("1_REASONABLE", quickapps__cms.labelPrjActivityAtV0);
		assertEquals(13, quickapps__cms.monthOfReachingTopBandCumPrjActivity);
		assertEquals(0.27, quickapps__cms.timeProgressAtPrjTopBand, 2);
		assertEquals(true, quickapps__cms.hasTailAtPrjTopBand);
		assertEquals(0, quickapps__cms.schemaBirthToTopMonthsWithoutChange);
		assertEquals(1, quickapps__cms.schemaBirthToTopMonthsWithChange);
		assertEquals(1/1, quickapps__cms.pctActiveMonthsInBirthToTop, 2);
		assertEquals(1/49, quickapps__cms.pctActiveBirthToTopOverDuration, 2);

	}//end testPerform

}

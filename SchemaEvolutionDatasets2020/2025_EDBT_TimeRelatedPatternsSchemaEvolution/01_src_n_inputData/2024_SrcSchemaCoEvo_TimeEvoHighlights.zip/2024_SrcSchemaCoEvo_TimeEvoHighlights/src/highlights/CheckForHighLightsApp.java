package highlights;

public class CheckForHighLightsApp {

	public static void main(String[] args) {
		String INPUT_FOLDER = "./resources/incoming/13_CumulativeProgress_Src-n-Schema";
		HighlightsEngine engine = new HighlightsEngine(INPUT_FOLDER);
		int numPrjProcessed = engine.performLagComputation();
		System.out.println("\n\nEND. Processed #prjs: " + numPrjProcessed);
	}

}

package visualizer;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYSeriesCollection;

import javax.swing.*;
import java.awt.*;


public class MultiXYLineChartVizWithMedoid extends JFrame {
	private static final long serialVersionUID = 6861127947735346288L;
	private String title;
	private XYSeriesCollection dataset;
	
	public MultiXYLineChartVizWithMedoid(String title, XYSeriesCollection dataset) {
        super(title);
		
		this.title = title;
		this.dataset = dataset;
        JPanel chartPanel = createChartPanel(this.title, "Time%", "SchemaEvo%");
        add(chartPanel, BorderLayout.CENTER);

        setSize(1000, 1000);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private JPanel createChartPanel(String title, String xAxisLabel, String yAxisLabel) {

        JFreeChart chart = ChartFactory.createXYLineChart(
                title,
                xAxisLabel,
                yAxisLabel,
                dataset,
                PlotOrientation.VERTICAL,
                true, true, false);
        // Get the plot
        XYPlot plot = chart.getXYPlot();

        // Set grey paint for all series, but the medoid
        for (int i = 0; i < dataset.getSeriesCount()-1; i++) {
            plot.getRenderer().setSeriesPaint(i, Color.LIGHT_GRAY);
        }
        plot.getRenderer().setSeriesPaint(dataset.getSeriesCount(), Color.RED);
        
        // sets plot background
        plot.setBackgroundPaint(Color.WHITE);
        return new ChartPanel(chart);
    }


}

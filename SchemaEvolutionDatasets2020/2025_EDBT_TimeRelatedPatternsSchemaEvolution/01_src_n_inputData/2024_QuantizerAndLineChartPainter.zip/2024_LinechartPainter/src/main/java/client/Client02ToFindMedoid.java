package client;

import java.io.File;
import java.io.IOException;

import javax.swing.SwingUtilities;

import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import medoid.MedoidExtractor;
import visualizer.FolderToSeriesCollectionConverter;
import visualizer.MultiXYLineChartViz;
import visualizer.MultiXYLineChartVizWithMedoid;

/**
 * We assume the processed input folder has the quantized timeseries.
 * All the t/s have the same number of timepoints at the x-axis
 * We use an L2 euclidean distance to find the one with the min total distance from everyone else.
 * 
 * @author pvassil
 *
 */
public class Client02ToFindMedoid {
	public static void main(String[] args) {
		
		//String sub = "11_FlatLiner" + "/";
		//String sub = "12_RadicalSign" + "/";
		//String sub = "13_Sigmoid" + "/";
		//String sub = "14_LateRiser" + "/";
		//String sub = "21_QuantumSteps" + "/";
		//String sub = "22_RegularlyCurated" + "/";
		//String sub = "31_SmokingFunnel" + "/";
		String sub = "32_Siesta" + "/";
		
//		String outputFolder = "src/test/resources/processedInput/10_Test/";
		String outputFolder = "src/test/resources/processedInput/" + sub;
		      
		FolderToSeriesCollectionConverter fToSConvOutput = new FolderToSeriesCollectionConverter();
		XYSeriesCollection xyOutSeriesCol = fToSConvOutput.createDataset(outputFolder, ".tsv", "\t", true, 0, 1);
        SwingUtilities.invokeLater(() -> new MultiXYLineChartViz(outputFolder, xyOutSeriesCol).setVisible(true));
        
        MedoidExtractor medoidExtractor = new MedoidExtractor();
        medoidExtractor.loadDataset(outputFolder, ".tsv", "\t", true, 0, 1);
        medoidExtractor.computeDistances();
        String medoidName = medoidExtractor.findMinDistance();
        System.out.println("\n\nMEDOID\n\t" + medoidName);
        
        String medoidPath = outputFolder+medoidName;
        System.out.println("\n\nMEDOID\n\t" + medoidPath);
        File medoidFile = new File(medoidPath);
        XYSeries medoidSeries = null;
        try {
			medoidSeries = fToSConvOutput.loadFileAsXYSeries(".tsv", "\t", true, 0, 1, medoidFile, "MEDOID");
		} catch (ArrayIndexOutOfBoundsException | NumberFormatException | IOException e) {
			e.printStackTrace();
		}
        if(null!=medoidSeries)
        	xyOutSeriesCol.addSeries(medoidSeries);
        SwingUtilities.invokeLater(() -> new MultiXYLineChartVizWithMedoid(outputFolder, xyOutSeriesCol).setVisible(true));
	}

}

//mkdir 10_Test
//mkdir 11_FlatLiner
//mkdir 12_RadicalSign
//mkdir 13_Sigmoid
//mkdir 14_LateRiser
//mkdir 21_QuantumSteps
//mkdir 22_RegularlyCurated
//mkdir 31_SmokingFunnel
//mkdir 32_Siesta
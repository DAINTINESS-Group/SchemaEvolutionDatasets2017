package visualizer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class FolderToSeriesCollectionConverter {

	public XYSeriesCollection createDataset(String dataPath, String extension, String delimiter, boolean hasHeaderLine, int posOfColumnX, int posOfColumnY) {
		XYSeriesCollection dataset = new XYSeriesCollection();
		File folder = new File(dataPath);

		if (folder.isDirectory()) {
			File[] files = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(extension));
			if (files != null) {
				for (File file : files) {
					XYSeries series = null;
					String title = file.getName().replace(extension, "");
					try {
						series = loadFileAsXYSeries(extension, delimiter, hasHeaderLine, posOfColumnX, posOfColumnY,  file, title);
					} catch (ArrayIndexOutOfBoundsException e) {
						e.printStackTrace();
					} catch (NumberFormatException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
					dataset.addSeries(series);
				}
			}
		}
		return dataset;
	}

	/**
	 * @param extension
	 * @param delimiter
	 * @param hasHeaderLine
	 * @param posOfColumnX
	 * @param posOfColumnY
	 * @param dataset
	 * @param file
	 */
	public XYSeries loadFileAsXYSeries(String extension, String delimiter, boolean hasHeaderLine, int posOfColumnX,
			int posOfColumnY, File file, String title) throws IOException, ArrayIndexOutOfBoundsException, NumberFormatException {
		XYSeries series = new XYSeries(title);
		BufferedReader br = new BufferedReader(new FileReader(file));
		if(hasHeaderLine)
			br.readLine();
		String line;
		while ((line = br.readLine()) != null) {
			String[] data = line.split(delimiter);
			Double xValue = Double.parseDouble(data[posOfColumnX]);
			Double yValue = Double.parseDouble(data[posOfColumnY]);
			series.add(xValue, yValue);
		}
		br.close();
		return series;
	}

}

package quantizer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.SortedMap;
import java.util.TreeMap;


public class Quantizer {
	private String inputFolder = "";
	private String outputFolder = "";
	private String extension; 
	private String delimiter; 
	private boolean hasHeaderLine; 
	private int posOfColumnX; 
	private int posOfColumnY;
	private int numOfQuanta;
	private SortedMap<Double, Double> inputSortedMap;
	
	public Quantizer(String inputFolder, String outputFolder, String extension, String delimiter, boolean hasHeaderLine,
			int posOfColumnX, int posOfColumnY, int numOfQuanta) {
		super();
		this.inputFolder = inputFolder;
		this.outputFolder = outputFolder;
		this.extension = extension;
		this.delimiter = delimiter;
		this.hasHeaderLine = hasHeaderLine;
		this.posOfColumnX = posOfColumnX;
		this.posOfColumnY = posOfColumnY;
		this.numOfQuanta = numOfQuanta;
		this.inputSortedMap = new TreeMap<>(); 

	}

	public void quantize() {
        File folder = new File(inputFolder);
        if (folder.isDirectory()) {
            File[] files = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(extension));
            if (files != null) {
                for (File file : files) {
                	String fileName = file.getName();
                	
            		this.inputSortedMap = new TreeMap<>(); 
            		for(int i = 0; i < numOfQuanta; i++) {
            			this.inputSortedMap.put(i/(1.0*numOfQuanta),null);
//            			System.out.println(i/(1.0*numOfQuanta));
            		}
            		this.inputSortedMap.put(1.0,1.0);
                	
                    loadData(delimiter, hasHeaderLine, posOfColumnX, posOfColumnY, file);
                    compensateMissingValues();
                    createFile(outputFolder, fileName);
                }
            }
        }
        else
			System.err.println("Folder " + inputFolder + " is not a valid folder" );
        //dataset.addSeries(produceCentroidNOTWORKING());
        return;
    }

	private void createFile(String outputFolder, String fileName) {
		String fullName = outputFolder+fileName;
		System.out.println("\n\nWriting " + fullName);
		try {
			BufferedWriter wr = new BufferedWriter(new FileWriter(fullName));
			wr.write("Key" + this.delimiter +" Value\n");
	        for (Double key : this.inputSortedMap.keySet()) {
	        	wr.write(key + this.delimiter + this.inputSortedMap.get(key)+"\n");
	        }
	        wr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	

	/**
	 * Populates sorted map with last value per quantum
	 * 
	 * @param delimiter
	 * @param hasHeaderLine
	 * @param posOfColumnX
	 * @param posOfColumnY
	 * @param file
	 */
	private void loadData(String delimiter, boolean hasHeaderLine, int posOfColumnX, int posOfColumnY, File file) {
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
		    if(hasHeaderLine)
		    	br.readLine();
		    String line;
		    while ((line = br.readLine()) != null) {
		        String[] data = line.split(delimiter);
		        Double xValue = Double.parseDouble(data[posOfColumnX]);
		        Double yValue = Double.parseDouble(data[posOfColumnY]);
		        addQuantizedXYValue(xValue, yValue);
		    }
		} catch (IOException | ArrayIndexOutOfBoundsException | NumberFormatException e) {
		    e.printStackTrace();
		}
	}

	/**
	 * updates each quantum's data with the last value it found for it
	 * 
	 * @param xValue
	 * @param yValue
	 */
    private void addQuantizedXYValue(Double xValue, Double yValue) {
    	Double roundedXValue = (double)Math.round(xValue * this.numOfQuanta * 1.0) / (this.numOfQuanta * 1.0);
    	this.inputSortedMap.put(roundedXValue, yValue);
    }

	private void compensateMissingValues() {
		Double prevValue = 0.0;
        for (Double key : this.inputSortedMap.keySet()) { 
            Double val = inputSortedMap.get(key);
         //   System.err.println(key + "\t" + val);
            if((null==val) ||(Double.NaN==val)) {
            	val = prevValue;
            	this.inputSortedMap.put(key, val);
            }
//            System.err.println(key + "\t" + val);
            prevValue = val;
        } 
	}
}//end class

package client;

import javax.swing.SwingUtilities;

import org.jfree.data.xy.XYSeriesCollection;

import quantizer.Quantizer;
import visualizer.FolderToSeriesCollectionConverter;
import visualizer.MultiXYLineChartViz;

public class Client01ToCreateQuantizedTimeSeries {

	public static void main(String[] args) {
		String sub = "32_Siesta" + "/";
//		String inputFolder = "src/test/resources/rawInput/10_Test/";
//		String outputFolder = "src/test/resources/processedInput/10_Test/";
		String inputFolder = "src/test/resources/rawInput/" + sub;
		String outputFolder = "src/test/resources/processedInput/" + sub;
		
		FolderToSeriesCollectionConverter fToSConv = new FolderToSeriesCollectionConverter();
		XYSeriesCollection xySeriesCol = fToSConv.createDataset(inputFolder, ".tsv", "\t", true, 3, 4);
        SwingUtilities.invokeLater(() -> new MultiXYLineChartViz(inputFolder, xySeriesCol).setVisible(true));

        Quantizer q = new Quantizer(inputFolder, outputFolder, ".tsv", "\t", true, 3, 4, 100);
        q.quantize();
        
		FolderToSeriesCollectionConverter fToSConvOutput = new FolderToSeriesCollectionConverter();
		XYSeriesCollection xyOutSeriesCol = fToSConvOutput.createDataset(outputFolder, ".tsv", "\t", true, 0, 1);
        SwingUtilities.invokeLater(() -> new MultiXYLineChartViz(outputFolder, xyOutSeriesCol).setVisible(true));
        
	}

}

//mkdir 10_Test
//mkdir 11_FlatLiner
//mkdir 12_RadicalSign
//mkdir 13_Sigmoid
//mkdir 14_LateRiser
//mkdir 21_QuantumSteps
//mkdir 22_RegularlyCurated
//mkdir 31_SmokingFunnel
//mkdir 32_Siesta
package medoid;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

//import org.apache.commons.math3.util.Pair;

public class MedoidExtractor {
	private SortedMap<String, List<Double>> yValues;
	private SortedMap<String, Double> totalDistances;
	
    public MedoidExtractor() {
		this.yValues = new TreeMap<String, List<Double>>();
		this.totalDistances = new TreeMap<String, Double>(); 
	}

	public void loadDataset(String dataPath, String extension, String delimiter, boolean hasHeaderLine, int posOfColumnX, int posOfColumnY) {

        File folder = new File(dataPath);
        if (folder.isDirectory()) {
            File[] files = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(extension));
            if (files != null) {
                for (File file : files) {
                	String fileName = file.getName();
                	//List<Double> xList = new ArrayList<Double>();
                	List<Double> yList = new ArrayList<Double>();
                	this.yValues.put(fileName, yList);
                	this.totalDistances.put(fileName, Double.NaN);
                	
                    try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                        if(hasHeaderLine)
                        	br.readLine();
                        String line;
                        while ((line = br.readLine()) != null) {
                            String[] data = line.split(delimiter);
                            Double xValue = Double.parseDouble(data[posOfColumnX]);
                            Double yValue = Double.parseDouble(data[posOfColumnY]);
                            yList.add(yValue);
                        }
                    } catch (IOException | ArrayIndexOutOfBoundsException | NumberFormatException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return;
    }//end method

	public void computeDistances() {
		String[] prjs = this.yValues.keySet().stream().toArray(String[] ::new);
		int totalNumPrjs = prjs.length;
		for(int i=0; i< totalNumPrjs-1; i++) {
			String prj = prjs[i];
			Double[] localYvalues = this.yValues.get(prj).stream().toArray(Double[]::new);
			//Double totalDistance = 0.0d;
			for(int j=i+1; j<totalNumPrjs; j++) {
				String prjJ = prjs[j];
				Double[] jYvalues = this.yValues.get(prjJ).stream().toArray(Double[]::new);
				Double localDistance = 0.0;
				for(int k=0; k < localYvalues.length; k++) {
						localDistance += Math.pow(localYvalues[k] - jYvalues[k],2);
				}
				localDistance = Math.sqrt(localDistance);
//				System.out.println(prj + " " + prjJ + ": " + localDistance);
				
				Double iTotalDistance = this.totalDistances.get(prj);
				if((null==iTotalDistance)||(Double.isNaN(iTotalDistance) ))
					iTotalDistance = 0.0d;
				Double xx = iTotalDistance + localDistance;
				
				this.totalDistances.put(prj, xx);
				Double jTotalDistance = this.totalDistances.get(prjJ);
				if((null==jTotalDistance)||(Double.isNaN(jTotalDistance) ))
					jTotalDistance = 0.0d;
				this.totalDistances.put(prjJ, jTotalDistance+localDistance);
				
			}//end j
		}//end i
	}//end method


	public String findMinDistance() {
		String medoidName = "";
		Double minDistance = Double.MAX_VALUE;
		for(String s: this.totalDistances.keySet()) {
			Double dist = this.totalDistances.get(s);
			System.out.println(s + ": " + dist);
			if (dist < minDistance) {
				minDistance = dist;
				medoidName = s;
			}
		}
		return medoidName;
	}
}//end class
